<?php

include("connectionDBFilm.php");

//variabili inserite
$titolo = $_POST["titolo"];
$annoProduzione = $_POST["annoProduzione"];
$nazionalita = $_POST["nazionalita"];
$regista = $_POST["regista"];
$genere = $_POST["genere"];
$durata = $_POST["durata"];

//seleziono tutti i titoli presenti nel database per controllare se già presente
$sql = "SELECT Titolo FROM film";
$result = $conn->query($sql);
$trovato = false;

//controllo
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        if ($titolo == $row["Titolo"]) {
            header("location:inserisci.php?msg=Film già presente!");
            $trovato = true;
            return 0;
        }
    }
}

//nuovo film
if ($trovato == false) {
    $sql = "INSERT INTO film (Titolo,AnnoProduzione,Nazionalita,Regista,Genere,Durata) VALUES ('$titolo', '$annoProduzione', '$nazionalita','$regista','$genere', '$durata')";
    if ($conn->query($sql) === TRUE) {
        //echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();

//upload file
if (isset($_FILES['userfile']['name'])) {
    $uploaddir = 'img/';
    $uploadfile = $uploaddir . $titolo . ".jpg";
    move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile);
}

header("location: elencoFilm.php");
